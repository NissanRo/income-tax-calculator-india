// Tax calculation data and logic
const taxData = {
  "taxSlabs": {
    "FY2024-25": {
      "oldRegime": {
        "individual": [
          {"min": 0, "max": 250000, "rate": 0},
          {"min": 250001, "max": 500000, "rate": 5},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ],
        "seniorCitizen": [
          {"min": 0, "max": 300000, "rate": 0},
          {"min": 300001, "max": 500000, "rate": 5},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ],
        "superSeniorCitizen": [
          {"min": 0, "max": 500000, "rate": 0},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ]
      },
      "newRegime": {
        "all": [
          {"min": 0, "max": 300000, "rate": 0},
          {"min": 300001, "max": 700000, "rate": 5},
          {"min": 700001, "max": 1000000, "rate": 10},
          {"min": 1000001, "max": 1200000, "rate": 15},
          {"min": 1200001, "max": 1500000, "rate": 20},
          {"min": 1500001, "max": 99999999, "rate": 30}
        ]
      },
      "standardDeduction": 75000,
      "rebate": {"limit": 700000, "amount": 25000}
    },
    "FY2025-26": {
      "oldRegime": {
        "individual": [
          {"min": 0, "max": 250000, "rate": 0},
          {"min": 250001, "max": 500000, "rate": 5},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ],
        "seniorCitizen": [
          {"min": 0, "max": 300000, "rate": 0},
          {"min": 300001, "max": 500000, "rate": 5},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ],
        "superSeniorCitizen": [
          {"min": 0, "max": 500000, "rate": 0},
          {"min": 500001, "max": 1000000, "rate": 20},
          {"min": 1000001, "max": 99999999, "rate": 30}
        ]
      },
      "newRegime": {
        "all": [
          {"min": 0, "max": 400000, "rate": 0},
          {"min": 400001, "max": 800000, "rate": 5},
          {"min": 800001, "max": 1200000, "rate": 10},
          {"min": 1200001, "max": 1600000, "rate": 15},
          {"min": 1600001, "max": 2000000, "rate": 20},
          {"min": 2000001, "max": 2400000, "rate": 25},
          {"min": 2400001, "max": 99999999, "rate": 30}
        ]
      },
      "standardDeduction": 75000,
      "rebate": {"limit": 1200000, "amount": 60000}
    }
  },
  "deductions": {
    "section80C": {
      "limit": 150000,
      "options": [
        {"name": "PPF", "description": "Public Provident Fund - 15 year lock-in, 7.1% return", "risk": "Low"},
        {"name": "EPF", "description": "Employee Provident Fund - 8.25% return", "risk": "Low"},
        {"name": "ELSS", "description": "Equity Linked Savings Scheme - 3 year lock-in, 12-15% potential return", "risk": "High"},
        {"name": "Tax Saving FD", "description": "5-year Fixed Deposit - 6-7% return", "risk": "Low"},
        {"name": "NSC", "description": "National Savings Certificate - 5 year lock-in, 7.7% return", "risk": "Low"},
        {"name": "Life Insurance", "description": "Premium payments qualify for deduction", "risk": "Low"},
        {"name": "Home Loan Principal", "description": "Principal repayment qualifies", "risk": "Low"},
        {"name": "Sukanya Samriddhi", "description": "For girl child education - 8.2% return", "risk": "Low"}
      ]
    },
    "section80D": {
      "selfFamily": {"below60": 25000, "above60": 50000},
      "parents": {"below60": 25000, "above60": 50000},
      "maxTotal": 100000,
      "preventiveCheckup": 5000
    },
    "section80CCD1B": {
      "limit": 50000,
      "description": "Additional NPS contribution deduction"
    },
    "otherDeductions": [
      {"section": "80E", "description": "Education loan interest", "limit": "No limit"},
      {"section": "80G", "description": "Donations to charitable institutions", "limit": "Varies"},
      {"section": "80GG", "description": "House rent paid (if no HRA)", "limit": "Rs. 5000 per month"}
    ]
  },
  "surchargeRates": [
    {"min": 5000001, "max": 10000000, "rate": 10},
    {"min": 10000001, "max": 20000000, "rate": 15},
    {"min": 20000001, "max": 50000000, "rate": 25},
    {"min": 50000001, "max": 99999999, "oldRate": 37, "newRate": 25}
  ],
  "cess": 4,
  "investmentComparison": [
    {
      "name": "ELSS Mutual Funds",
      "lockIn": "3 years",
      "returns": "12-15% (market linked)",
      "risk": "High",
      "taxBenefit": "80C deduction up to ₹1.5L + LTCG up to ₹1.25L tax free",
      "pros": ["Highest return potential", "Shortest lock-in", "Professional management"],
      "cons": ["Market risk", "No guaranteed returns"]
    },
    {
      "name": "Public Provident Fund (PPF)",
      "lockIn": "15 years",
      "returns": "7.1% (guaranteed)",
      "risk": "Low",
      "taxBenefit": "80C deduction + tax-free returns + tax-free maturity",
      "pros": ["Triple tax benefit (EEE)", "Government backed", "Compounding benefit"],
      "cons": ["Long lock-in", "Lower returns", "Limited annual contribution"]
    },
    {
      "name": "National Pension System (NPS)",
      "lockIn": "Till retirement",
      "returns": "8-12% (market linked)",
      "risk": "Medium",
      "taxBenefit": "80C deduction + additional 80CCD(1B) ₹50k + employer contribution 80CCD(2)",
      "pros": ["Highest tax benefits", "Retirement focused", "Low costs"],
      "cons": ["Partial withdrawal only", "Mandatory annuity", "Long lock-in"]
    },
    {
      "name": "Tax Saving Fixed Deposits",
      "lockIn": "5 years",
      "returns": "6-7% (guaranteed)",
      "risk": "Very Low",
      "taxBenefit": "80C deduction only",
      "pros": ["Capital protection", "Guaranteed returns", "Bank security"],
      "cons": ["Lower returns", "Interest taxable", "No inflation protection"]
    }
  ],
  "taxTips": [
    {
      "category": "New Tax Regime Benefits",
      "tips": [
        "Income up to ₹12 lakh is tax-free in FY 2024-25, ₹12.75 lakh in FY 2025-26",
        "No need to maintain investment proofs",
        "Higher standard deduction of ₹75,000",
        "Suitable for those with minimal deductions"
      ]
    },
    {
      "category": "Old Tax Regime Strategies",
      "tips": [
        "Maximize ₹1.5L deduction under Section 80C",
        "Claim health insurance under 80D up to ₹1L",
        "Use HRA exemption if paying rent",
        "Optimize home loan interest deduction",
        "Better for those with substantial eligible expenses"
      ]
    },
    {
      "category": "Investment Planning",
      "tips": [
        "ELSS for wealth creation with tax benefits",
        "PPF for long-term tax-free savings",
        "NPS for retirement + maximum tax benefits",
        "Diversify across different 80C instruments",
        "Start SIP in ELSS for rupee cost averaging"
      ]
    },
    {
      "category": "HRA Optimization",
      "tips": [
        "HRA exemption = min of (actual HRA, 50%/40% of salary, rent - 10% salary)",
        "Metro cities get 50% benefit, non-metro 40%",
        "Keep rent receipts and rental agreement",
        "Consider paying rent to parents (with proper documentation)"
      ]
    }
  ]
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  initializeTabs();
  initializeSlabsSection();
  initializeTipsSection();
  initializeDeductionsSection();
  initializeFAQsSection();
});

// Tab functionality
function initializeTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      
      // Remove active class from all tabs and contents
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding content
      btn.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    });
  });
}

// Tax calculation functions
function calculateHRAExemption(hra, salary, rentPaid, cityType) {
  if (hra === 0 || rentPaid === 0) return 0;
  
  const annualRent = rentPaid * 12;
  const salaryPercentage = cityType === 'metro' ? 0.5 : 0.4;
  const rentMinusSalary = Math.max(0, annualRent - (salary * 0.1));
  
  return Math.min(hra, salary * salaryPercentage, rentMinusSalary);
}

function calculateTaxOnIncome(income, slabs) {
  let tax = 0;
  
  for (const slab of slabs) {
    if (income > slab.min) {
      const taxableInThisSlab = Math.min(income, slab.max) - slab.min + 1;
      tax += (taxableInThisSlab * slab.rate) / 100;
    }
  }
  
  return Math.round(tax);
}

function calculateSurcharge(tax, income, isNewRegime = false) {
  let surcharge = 0;
  
  for (const rate of taxData.surchargeRates) {
    if (income >= rate.min && income <= rate.max) {
      const surchargeRate = isNewRegime && rate.newRate ? rate.newRate : 
                           (rate.oldRate || rate.rate);
      surcharge = (tax * surchargeRate) / 100;
      break;
    }
  }
  
  return Math.round(surcharge);
}

function calculateTax() {
  // Get form values
  const financialYear = document.getElementById('financialYear').value;
  const taxpayerCategory = document.getElementById('taxpayerCategory').value;
  const grossSalary = parseFloat(document.getElementById('grossSalary').value) || 0;
  const hra = parseFloat(document.getElementById('hra').value) || 0;
  const rentPaid = parseFloat(document.getElementById('rentPaid').value) || 0;
  const cityType = document.getElementById('cityType').value;
  const otherIncome = parseFloat(document.getElementById('otherIncome').value) || 0;
  
  // Deductions (only for old regime)
  const section80C = Math.min(parseFloat(document.getElementById('section80C').value) || 0, 150000);
  const section80D = parseFloat(document.getElementById('section80D').value) || 0;
  const section80DParents = parseFloat(document.getElementById('section80DParents').value) || 0;
  const section80CCD1B = Math.min(parseFloat(document.getElementById('section80CCD1B').value) || 0, 50000);
  const section80E = parseFloat(document.getElementById('section80E').value) || 0;
  const homeLoanInterest = Math.min(parseFloat(document.getElementById('homeLoanInterest').value) || 0, 200000);
  
  // Calculate HRA exemption
  const hraExemption = calculateHRAExemption(hra, grossSalary, rentPaid, cityType);
  
  // Get tax slabs for the selected year
  const yearData = taxData.taxSlabs[financialYear];
  const standardDeduction = yearData.standardDeduction;
  
  // Calculate for Old Regime
  const oldRegimeSlabs = yearData.oldRegime[taxpayerCategory];
  const totalIncome = grossSalary + otherIncome;
  const oldTaxableIncome = Math.max(0, totalIncome - standardDeduction - hraExemption - 
    section80C - section80D - section80DParents - section80CCD1B - section80E - homeLoanInterest);
  
  let oldTaxBeforeRebate = calculateTaxOnIncome(oldTaxableIncome, oldRegimeSlabs);
  let oldTaxAfterRebate = oldTaxBeforeRebate;
  
  // Apply rebate for old regime (only for individuals)
  if (taxpayerCategory === 'individual' && oldTaxableIncome <= 500000) {
    oldTaxAfterRebate = Math.max(0, oldTaxBeforeRebate - Math.min(oldTaxBeforeRebate, 12500));
  }
  
  const oldSurcharge = calculateSurcharge(oldTaxAfterRebate, oldTaxableIncome, false);
  const oldCess = Math.round((oldTaxAfterRebate + oldSurcharge) * taxData.cess / 100);
  const oldTotalTax = oldTaxAfterRebate + oldSurcharge + oldCess;
  
  // Calculate for New Regime
  const newRegimeSlabs = yearData.newRegime.all;
  const newTaxableIncome = Math.max(0, totalIncome - standardDeduction);
  
  let newTaxBeforeRebate = calculateTaxOnIncome(newTaxableIncome, newRegimeSlabs);
  let newTaxAfterRebate = newTaxBeforeRebate;
  
  // Apply rebate for new regime
  if (newTaxableIncome <= yearData.rebate.limit) {
    newTaxAfterRebate = Math.max(0, newTaxBeforeRebate - Math.min(newTaxBeforeRebate, yearData.rebate.amount));
  }
  
  const newSurcharge = calculateSurcharge(newTaxAfterRebate, newTaxableIncome, true);
  const newCess = Math.round((newTaxAfterRebate + newSurcharge) * taxData.cess / 100);
  const newTotalTax = newTaxAfterRebate + newSurcharge + newCess;
  
  // Display results
  displayResults(
    oldTaxableIncome, oldTaxBeforeRebate, oldTaxAfterRebate, oldSurcharge, oldCess, oldTotalTax,
    newTaxableIncome, newTaxBeforeRebate, newTaxAfterRebate, newSurcharge, newCess, newTotalTax
  );
}

function displayResults(oldTaxableIncome, oldTaxBeforeRebate, oldTaxAfterRebate, oldSurcharge, oldCess, oldTotalTax,
                       newTaxableIncome, newTaxBeforeRebate, newTaxAfterRebate, newSurcharge, newCess, newTotalTax) {
  
  // Format currency
  const formatCurrency = (amount) => `₹${amount.toLocaleString('en-IN')}`;
  
  // Update old regime results
  document.getElementById('oldTaxableIncome').textContent = formatCurrency(oldTaxableIncome);
  document.getElementById('oldTaxBeforeRebate').textContent = formatCurrency(oldTaxBeforeRebate);
  document.getElementById('oldTaxAfterRebate').textContent = formatCurrency(oldTaxAfterRebate);
  document.getElementById('oldSurcharge').textContent = formatCurrency(oldSurcharge);
  document.getElementById('oldCess').textContent = formatCurrency(oldCess);
  document.getElementById('oldTotalTax').textContent = formatCurrency(oldTotalTax);
  
  // Update new regime results
  document.getElementById('newTaxableIncome').textContent = formatCurrency(newTaxableIncome);
  document.getElementById('newTaxBeforeRebate').textContent = formatCurrency(newTaxBeforeRebate);
  document.getElementById('newTaxAfterRebate').textContent = formatCurrency(newTaxAfterRebate);
  document.getElementById('newSurcharge').textContent = formatCurrency(newSurcharge);
  document.getElementById('newCess').textContent = formatCurrency(newCess);
  document.getElementById('newTotalTax').textContent = formatCurrency(newTotalTax);
  
  // Show recommendation
  const savings = Math.abs(oldTotalTax - newTotalTax);
  const recommendedRegime = oldTotalTax < newTotalTax ? 'Old Tax Regime' : 'New Tax Regime';
  const savingsText = savings > 0 ? `You can save ${formatCurrency(savings)} by choosing the ${recommendedRegime}.` : 'Both regimes result in the same tax liability.';
  
  document.getElementById('recommendationText').textContent = `Recommended: ${recommendedRegime}`;
  document.getElementById('savingsText').textContent = savingsText;
  
  // Show results section
  document.getElementById('taxResults').classList.remove('hidden');
}

// Initialize Tax Slabs Section
function initializeSlabsSection() {
  const yearButtons = document.querySelectorAll('.year-selector .btn');
  
  yearButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      yearButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const year = btn.getAttribute('data-year');
      displayTaxSlabs(year);
    });
  });
  
  // Initialize with FY2024-25
  displayTaxSlabs('FY2024-25');
}

function displayTaxSlabs(year) {
  const yearData = taxData.taxSlabs[year];
  const container = document.getElementById('slabsContent');
  
  let html = `
    <h3 class="regime-title">Old Tax Regime - ${year}</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;">
      ${generateSlabTable('Individual (<60)', yearData.oldRegime.individual)}
      ${generateSlabTable('Senior Citizen (60-80)', yearData.oldRegime.seniorCitizen)}
      ${generateSlabTable('Super Senior (>80)', yearData.oldRegime.superSeniorCitizen)}
    </div>
    
    <h3 class="regime-title">New Tax Regime - ${year}</h3>
    <div style="max-width: 600px; margin: 0 auto;">
      ${generateSlabTable('All Categories', yearData.newRegime.all)}
    </div>
    
    <div style="background: var(--color-bg-3); padding: 20px; border-radius: 8px; margin-top: 30px;">
      <h4>Key Differences:</h4>
      <ul style="margin: 0; padding-left: 20px;">
        <li>Standard Deduction: ₹${yearData.standardDeduction.toLocaleString()}</li>
        <li>Rebate Limit: ₹${yearData.rebate.limit.toLocaleString()} (Max rebate: ₹${yearData.rebate.amount.toLocaleString()})</li>
        <li>Old regime allows various deductions under sections 80C, 80D, etc.</li>
        <li>New regime has no deductions but lower tax rates</li>
      </ul>
    </div>
  `;
  
  container.innerHTML = html;
}

function generateSlabTable(category, slabs) {
  let tableHtml = `
    <div class="card">
      <div class="card__body">
        <h4 style="margin-bottom: 16px; text-align: center;">${category}</h4>
        <table class="slab-table">
          <thead>
            <tr>
              <th>Income Range</th>
              <th>Tax Rate</th>
            </tr>
          </thead>
          <tbody>
  `;
  
  slabs.forEach(slab => {
    const minFormatted = slab.min === 0 ? '0' : `₹${slab.min.toLocaleString()}`;
    const maxFormatted = slab.max >= 99999999 ? 'Above' : `₹${slab.max.toLocaleString()}`;
    const range = slab.max >= 99999999 ? `${minFormatted} and above` : `${minFormatted} - ${maxFormatted}`;
    
    tableHtml += `
      <tr>
        <td>${range}</td>
        <td>${slab.rate}%</td>
      </tr>
    `;
  });
  
  tableHtml += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  return tableHtml;
}

// Initialize Tips Section
function initializeTipsSection() {
  const container = document.getElementById('tipsContent');
  
  let html = '';
  
  // Tax Tips
  taxData.taxTips.forEach(category => {
    html += `
      <div class="tip-category">
        <h3>${category.category}</h3>
        <ul>
          ${category.tips.map(tip => `<li>${tip}</li>`).join('')}
        </ul>
      </div>
    `;
  });
  
  // Investment Comparison
  html += '<h2 style="margin: 40px 0 20px 0; text-align: center;">Investment Options Comparison</h2>';
  
  taxData.investmentComparison.forEach(investment => {
    html += `
      <div class="investment-card">
        <div class="investment-header">
          <h4>${investment.name}</h4>
        </div>
        <div class="investment-body">
          <div class="investment-details">
            <div class="detail-item">
              <span class="detail-label">Lock-in Period</span>
              <span class="detail-value">${investment.lockIn}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Expected Returns</span>
              <span class="detail-value">${investment.returns}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Risk Level</span>
              <span class="detail-value risk-${investment.risk.toLowerCase()}">${investment.risk}</span>
            </div>
          </div>
          <div class="detail-item" style="margin-bottom: 16px;">
            <span class="detail-label">Tax Benefits</span>
            <span class="detail-value">${investment.taxBenefit}</span>
          </div>
          <div class="pros-cons">
            <div class="pros">
              <h5>Pros</h5>
              <ul>
                ${investment.pros.map(pro => `<li>${pro}</li>`).join('')}
              </ul>
            </div>
            <div class="cons">
              <h5>Cons</h5>
              <ul>
                ${investment.cons.map(con => `<li>${con}</li>`).join('')}
              </ul>
            </div>
          </div>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = html;
}

// Initialize Deductions Section
function initializeDeductionsSection() {
  const container = document.getElementById('deductionsContent');
  
  let html = `
    <div class="deduction-section">
      <div class="deduction-header">
        <h3>Section 80C - Maximum Deduction: ₹1,50,000</h3>
      </div>
      <div class="deduction-body">
        <div class="deduction-options">
          ${taxData.deductions.section80C.options.map(option => `
            <div class="deduction-option">
              <div class="option-name">${option.name}</div>
              <div class="option-description">${option.description}</div>
              <div class="option-risk risk-${option.risk.toLowerCase()}">${option.risk} Risk</div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
    
    <div class="deduction-section">
      <div class="deduction-header">
        <h3>Section 80D - Health Insurance Premiums</h3>
      </div>
      <div class="deduction-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
          <div class="deduction-option">
            <div class="option-name">Self & Family</div>
            <div class="option-description">Below 60 years: ₹${taxData.deductions.section80D.selfFamily.below60.toLocaleString()}<br>Above 60 years: ₹${taxData.deductions.section80D.selfFamily.above60.toLocaleString()}</div>
          </div>
          <div class="deduction-option">
            <div class="option-name">Parents</div>
            <div class="option-description">Below 60 years: ₹${taxData.deductions.section80D.parents.below60.toLocaleString()}<br>Above 60 years: ₹${taxData.deductions.section80D.parents.above60.toLocaleString()}</div>
          </div>
          <div class="deduction-option">
            <div class="option-name">Preventive Health Checkup</div>
            <div class="option-description">Additional ₹${taxData.deductions.section80D.preventiveCheckup.toLocaleString()} for preventive health checkup (included in above limits)</div>
          </div>
        </div>
        <p style="margin-top: 16px; color: var(--color-text-secondary);">Maximum total deduction under 80D: ₹${taxData.deductions.section80D.maxTotal.toLocaleString()}</p>
      </div>
    </div>
    
    <div class="deduction-section">
      <div class="deduction-header">
        <h3>Section 80CCD(1B) - Additional NPS Contribution</h3>
      </div>
      <div class="deduction-body">
        <p>${taxData.deductions.section80CCD1B.description}</p>
        <p>Maximum deduction: ₹${taxData.deductions.section80CCD1B.limit.toLocaleString()}</p>
      </div>
    </div>
    
    <div class="deduction-section">
      <div class="deduction-header">
        <h3>Other Important Deductions</h3>
      </div>
      <div class="deduction-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
          ${taxData.deductions.otherDeductions.map(deduction => `
            <div class="deduction-option">
              <div class="option-name">Section ${deduction.section}</div>
              <div class="option-description">${deduction.description}</div>
              <div style="margin-top: 8px; font-weight: 500;">Limit: ${deduction.limit}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
  
  container.innerHTML = html;
}

// Initialize FAQs Section
function initializeFAQsSection() {
  const faqs = [
    {
      question: "Which tax regime should I choose - Old or New?",
      answer: "It depends on your deductions. If your total eligible deductions (80C, 80D, HRA, etc.) are more than ₹75,000, the old regime might be better. If you have minimal deductions, the new regime with its higher exemption limit could save more tax. Use our calculator to compare both scenarios."
    },
    {
      question: "Can I switch between tax regimes every year?",
      answer: "Yes, salaried individuals can choose between old and new tax regimes every financial year. However, if you have business income, you can switch only once in your lifetime (except for the first time)."
    },
    {
      question: "What is the standard deduction in both regimes?",
      answer: "Both old and new tax regimes offer a standard deduction of ₹75,000 for FY 2024-25 and FY 2025-26. This is automatically available to all salaried individuals."
    },
    {
      question: "How is HRA exemption calculated?",
      answer: "HRA exemption is the minimum of: (1) Actual HRA received, (2) 50% of salary for metro cities or 40% for non-metro cities, (3) Annual rent paid minus 10% of salary. HRA exemption is only available in the old tax regime."
    },
    {
      question: "What are the rebate limits for FY 2025-26?",
      answer: "For FY 2025-26: Old regime - No specific rebate for general taxpayers. New regime - Rebate of up to ₹60,000 if total income is up to ₹12 lakh, making income up to ₹12.75 lakh effectively tax-free."
    },
    {
      question: "Can I claim both 80C and NPS 80CCD(1B) deductions?",
      answer: "Yes, you can claim both. Section 80C allows up to ₹1.5 lakh deduction, and Section 80CCD(1B) allows additional ₹50,000 deduction specifically for NPS contributions, making the total possible deduction ₹2 lakh."
    },
    {
      question: "What happens if I don't submit investment proofs?",
      answer: "If you choose the old regime but don't submit investment proofs, TDS will be deducted as per the new regime rates. You can claim the deductions while filing your ITR and get a refund if eligible."
    },
    {
      question: "Are there any changes in surcharge and cess rates?",
      answer: "Surcharge rates vary based on income levels and regime. For the new regime, the maximum surcharge is capped at 25% for income above ₹5 crore, while the old regime has 37%. Health and Education Cess remains 4% on (tax + surcharge) for both regimes."
    }
  ];
  
  const container = document.getElementById('faqsContent');
  
  let html = '';
  
  faqs.forEach((faq, index) => {
    html += `
      <div class="faq-item">
        <div class="faq-question" onclick="toggleFAQ(${index})">
          <span>${faq.question}</span>
          <span class="faq-icon" id="faq-icon-${index}">+</span>
        </div>
        <div class="faq-answer" id="faq-answer-${index}" style="display: none;">
          ${faq.answer}
        </div>
      </div>
    `;
  });
  
  container.innerHTML = html;
}

function toggleFAQ(index) {
  const answer = document.getElementById(`faq-answer-${index}`);
  const icon = document.getElementById(`faq-icon-${index}`);
  
  if (answer.style.display === 'none') {
    answer.style.display = 'block';
    icon.textContent = '-';
  } else {
    answer.style.display = 'none';
    icon.textContent = '+';
  }
}

// Print functionality
function printResults() {
  const printContent = document.getElementById('taxResults').outerHTML;
  const printWindow = window.open('', '', 'height=600,width=800');
  
  printWindow.document.write(`
    <html>
      <head>
        <title>Tax Calculation Results</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .regime-comparison { display: flex; gap: 20px; }
          .regime-card { border: 1px solid #ccc; padding: 15px; flex: 1; }
          .result-item { display: flex; justify-content: space-between; margin: 5px 0; }
          .total { font-weight: bold; border-top: 2px solid #333; margin-top: 10px; padding-top: 10px; }
          .recommendation { background: #f0f8ff; padding: 15px; margin: 15px 0; border-left: 4px solid #007cba; }
          h3, h4 { color: #333; }
        </style>
      </head>
      <body>
        <h1>Income Tax Calculation Results</h1>
        ${printContent.replace(/class="btn[^"]*"/g, 'style="display:none"')}
      </body>
    </html>
  `);
  
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
}